
import numpy as np
from scipy.optimize import linprog

# 数学建模问题 - 线性规划解决方案
# 变量定义:
# x1: 混合池中甲的用量(t)
# x2: 混合池中乙的用量(t)
# x3: 混合池中丁的用量(t)
# y1: 用于生产A的混合液量(t)
# y2: 用于生产B的混合液量(t)
# z1: 用于生产A的丙的用量(t)
# z2: 用于生产B的丙的用量(t)

# 目标函数: 最大化利润 = 销售收入 - 原料成本
# 由于linprog求解的是最小化问题，所以我们取目标函数的相反数
c = [6-9, 16-9, 15-9, -9, -15, 10-9, 10-15]

# 约束条件
A_ub = []
b_ub = []

# 混合液物料平衡: y1 + y2 <= x1 + x2 + x3
A_ub.append([-1, -1, -1, 1, 1, 0, 0])
b_ub.append(0)

# 产品A的产量约束: y1 + z1 <= 100
A_ub.append([0, 0, 0, 1, 0, 1, 0])
b_ub.append(100)

# 产品B的产量约束: y2 + z2 <= 200
A_ub.append([0, 0, 0, 0, 1, 0, 1])
b_ub.append(200)

# 原料丁的供应量约束: x3 <= 50
A_ub.append([0, 0, 1, 0, 0, 0, 0])
b_ub.append(50)

# 产品A的含硫量约束: 3x1 + x2 + x3 + 2z1 <= 2.5(y1 + z1)
A_ub.append([3, 1, 1, -2.5, 0, -0.5, 0])
b_ub.append(0)

# 产品B的含硫量约束: 3x1 + x2 + x3 + 2z2 <= 1.5(y2 + z2)
A_ub.append([3, 1, 1, 0, -1.5, 0, 0.5])
b_ub.append(0)

# 所有变量非负
bounds = [(0, None) for _ in range(7)]

# 转换为numpy数组
A_ub = np.array(A_ub)
b_ub = np.array(b_ub)

# 求解线性规划问题
result = linprog(c, A_ub=A_ub, b_ub=b_ub, bounds=bounds)

print(result)
# 输出结果
if result.success:
    x = result.x
    print("优化结果:")
    print(f"最大利润: {abs(result.fun):.2f} 千元")
    print("各原料使用量(t):")
    print(f"混合池中甲原料: {x[0]:.2f}")
    print(f"混合池中乙原料: {x[1]:.2f}")
    print(f"混合池中丁原料: {x[2]:.2f}")
    print(f"用于生产A的混合液: {x[3]:.2f}")
    print(f"用于生产B的混合液: {x[4]:.2f}")
    print(f"用于生产A的丙原料: {x[5]:.2f}")
    print(f"用于生产B的丙原料: {x[6]:.2f}")
    print("产品产量(t):")
    print(f"产品A: {x[3] + x[5]:.2f}")
    print(f"产品B: {x[4] + x[6]:.2f}")
    
    # 验证约束条件
    mix_pool_input = x[0] + x[1] + x[2]
    mix_pool_output = x[3] + x[4]
    print(f"混合池物料平衡: 输入={mix_pool_input:.2f}t, 输出={mix_pool_output:.2f}t")
    print(f"原料丁总用量: {x[2]:.2f}t (≤ 50t)")
else:
    print("无法找到最优解")
    print("原因:", result.message)
